## color-picker - forked from v1.0.9

codemirror-colorpicker was **heavily** modified from its source:

https://github.com/easylogic/codemirror-colorpicker/...

Shortly after this version the source repo split the file and built it using rollup. It should be considered a fork of the original.
